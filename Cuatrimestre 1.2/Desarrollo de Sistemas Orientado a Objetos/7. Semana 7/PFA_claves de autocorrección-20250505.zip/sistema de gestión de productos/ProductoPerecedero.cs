﻿namespace Semana8
{
    class ProductoPerecedero : Producto
    {
        public int DiasACaducar { get; set; }

 
    }
}
