﻿namespace Semana8
{
    abstract class Producto
    {
        public string Nombre { get; set; }
        public double Precio { get; set; }
        public string Tipo { get; set; }

 
    }

}
