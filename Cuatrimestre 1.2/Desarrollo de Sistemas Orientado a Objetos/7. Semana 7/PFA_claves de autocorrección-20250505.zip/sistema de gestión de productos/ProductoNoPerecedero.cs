﻿namespace Semana8
{
    class ProductoNoPerecedero : Producto
    {
        public string Categoria{ get; set; }

 
    }
}
