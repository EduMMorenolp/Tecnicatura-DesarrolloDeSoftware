﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Semana12
{
    public class Circulo : IAreaCalculable
    {
        public double Radio { get; set; }

        public Circulo(double radio)
        {
            Radio = radio;
        }

        public double CalcularArea()
        {
            return Math.PI * Radio * Radio;
        }
    }
}
