﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Semana12
{
    public class CuadradoInformacion : Cuadrado, IInformacionFigura
    {
        public CuadradoInformacion(double lado) : base(lado)
        {
        }

        public string ObtenerInformacion()
        {
            double area = CalcularArea();
            return $"Cuadrado - Lado: {Lado}, Área: {area}";
        }
    }

}
