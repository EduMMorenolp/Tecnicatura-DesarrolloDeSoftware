﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Semana12
{
    internal interface IInformacionFigura
    {
        string ObtenerInformacion();
    }
}
