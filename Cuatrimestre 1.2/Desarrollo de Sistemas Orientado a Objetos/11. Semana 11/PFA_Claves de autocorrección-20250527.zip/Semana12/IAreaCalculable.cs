﻿using System;

namespace Semana12
{
    internal interface IAreaCalculable
    {
        double CalcularArea();
    }
}
