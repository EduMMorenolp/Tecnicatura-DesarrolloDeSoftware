﻿using System;
using System.Collections.Generic;

namespace Semana12
{
    internal class Test
    {
        static void Main(string[] args)
        {
            List<IInformacionFigura> figuras = new List<IInformacionFigura>();

 //           Cuadrado cuadrado1 = new Cuadrado(5.0);
 //           Circulo circulo = new Circulo(3.0);
            IInformacionFigura cuadradoInfo = new CuadradoInformacion(7.5);
            IInformacionFigura circuloInfo = new CirculoInformacion(5.0);

            figuras.Add(cuadradoInfo);
            figuras.Add(circuloInfo);
            foreach (var figura in figuras)
            {
                ImprimirInformacionFigura(figura);
            }
        }

        static void ImprimirInformacionFigura(IInformacionFigura figura)
        {
            string informacion = figura.ObtenerInformacion();
            Console.WriteLine(informacion);
        }
    }
}
