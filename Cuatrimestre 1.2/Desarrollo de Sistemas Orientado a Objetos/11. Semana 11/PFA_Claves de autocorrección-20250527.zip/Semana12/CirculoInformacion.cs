﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Semana12
{
    public class CirculoInformacion : Circulo, IInformacionFigura
    {
        public CirculoInformacion(double radio) : base(radio)
        {
        }

        public string ObtenerInformacion()
        {
            double area = CalcularArea();
            return $"Círculo - Radio: {Radio}, Área: {area}";
        }
    }
}
