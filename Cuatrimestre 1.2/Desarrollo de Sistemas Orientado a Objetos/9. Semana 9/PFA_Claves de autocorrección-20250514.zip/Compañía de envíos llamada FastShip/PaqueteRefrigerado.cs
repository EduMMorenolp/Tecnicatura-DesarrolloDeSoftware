﻿// Clase derivada: PaqueteRefrigerado
using System;

public class PaqueteRefrigerado : Paquete
{
    private double temperatura;

    public PaqueteRefrigerado(double peso, double dimensiones, string direccionDestino, double temperatura)
        : base(peso, dimensiones, direccionDestino)
    {
        this.temperatura = temperatura;
    }

    public override double CalcularCostoDeEnvio()
    {
        // Lógica para el cálculo del costo de envío para paquetes refrigerados
        const double PORCENTAJE_RECARGO_MAS_10 = 50;
        const double PORCENTAJE_RECARGO_MENOR_IGUAL_10 = 200;
        double porcentajeRecargo, costoEnvio;
        costoEnvio = base.CalcularCostoDeEnvio();
        if (temperatura > 10)
            porcentajeRecargo = PORCENTAJE_RECARGO_MAS_10;
        else
            porcentajeRecargo = PORCENTAJE_RECARGO_MENOR_IGUAL_10;
        costoEnvio += costoEnvio * porcentajeRecargo/100;
        return costoEnvio;
    }

    public override void MostrarInformacionDetallada()
    {
        base.MostrarInformacionDetallada();
        Console.WriteLine("Temperatura requerida: " + temperatura + " °C");
    }
}