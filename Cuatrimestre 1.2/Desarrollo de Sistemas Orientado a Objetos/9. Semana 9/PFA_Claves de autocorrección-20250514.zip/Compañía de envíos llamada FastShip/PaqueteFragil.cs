﻿// Clase derivada: PaqueteFragil
public class PaqueteFragil : Paquete
{
    public PaqueteFragil(double peso, double dimensiones, string direccionDestino)
        : base(peso, dimensiones, direccionDestino)
    {
    }

    public override double CalcularCostoDeEnvio()
    {
        // Lógica para el cálculo del costo de envío para paquetes frágiles
        double costoEnvio = base.CalcularCostoDeEnvio() * 2;
        return costoEnvio;
    }
}