﻿// Clase base: Paquete
using System;

public class Paquete
{
    private double peso;
    private double dimensiones;
    private string direccionDestino;

    public Paquete(double peso, double dimensiones, string direccionDestino)
    {
        this.peso = peso;
        this.dimensiones = dimensiones;
        this.direccionDestino = direccionDestino;
    }

    public virtual double CalcularCostoDeEnvio()
    {
        // Lógica para el cálculo del costo de envío para paquetes regulares
        // Puedes implementar la lógica específica aquí o en las clases derivadas.
        // En este caso, no se implementa nada en la clase base.
        const double TARIFA_REGULAR = 10.0; // Tarifa base para paquetes regulares
        double costoEnvio = TARIFA_REGULAR * peso;
        return costoEnvio;
        //return 0.0;
    }

    public virtual void MostrarInformacionDetallada()
    {
        Console.WriteLine("Información del paquete:");
        Console.WriteLine("Peso: " + peso + " kg");
        Console.WriteLine("Dimensiones: " + dimensiones + " m2");
        Console.WriteLine("Dirección de destino: " + direccionDestino);
    }
}
