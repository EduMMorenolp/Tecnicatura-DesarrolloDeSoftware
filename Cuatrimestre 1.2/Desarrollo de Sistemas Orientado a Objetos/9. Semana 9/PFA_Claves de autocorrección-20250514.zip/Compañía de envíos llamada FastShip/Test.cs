﻿using System;
using System.Collections.Generic;
// Clase principal del programa
public class Test
{
    public static void Main()
    {
        // Ejemplo de uso del sistema
        List<Paquete> paquetes = new List<Paquete>(); 
        paquetes.Add(new Paquete(5.0, 0.2, "Calle Principal 123"));
        paquetes.Add(new PaqueteFragil(5.0, 0.1, "Avenida Central 456"));
        paquetes.Add(new PaqueteRefrigerado(5, 0.3, "Plaza Mayor 789", 4.0));
        paquetes.Add(new PaqueteRefrigerado(5, 0.3, "Plaza Mayor 789", 24.0));

        // Cálculo y muestra del costo de envío e información detallada de cada paquete
        foreach (Paquete p in paquetes)
            MostrarCostoDeEnvio(p);
    }

    public static void MostrarCostoDeEnvio(Paquete paquete)
    {
        double costoEnvio = paquete.CalcularCostoDeEnvio();
        Console.WriteLine($"Costo de envío: {costoEnvio:C}");
        paquete.MostrarInformacionDetallada();
        Console.WriteLine("-----------------------");
    }
}