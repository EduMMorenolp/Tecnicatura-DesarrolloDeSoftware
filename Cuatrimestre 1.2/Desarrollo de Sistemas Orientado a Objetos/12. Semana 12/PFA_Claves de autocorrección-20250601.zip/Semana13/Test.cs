﻿using Semana13;
using System;

class GeometricCalculator
{

}

class Test
{
    static void Main(string[] args)
    {
        int opcion;

        do
        {
            opcion = Menu();

            switch (opcion)
            {
                case 1:
                    Console.Write("Ingrese el radio del círculo: ");
                    CalculadoraGeometria.RadioCirculo = double.Parse(Console.ReadLine());
                    Console.WriteLine($"Área del círculo: {CalculadoraGeometria.CalcularAreaCirculo()}");
                    Console.WriteLine($"Perímetro del círculo: {CalculadoraGeometria.CalcularPerimetroCirculo()}");
                    break;
                case 2:
                    Console.Write("Ingrese el ancho del rectángulo: ");
                    CalculadoraGeometria.AnchoRectangulo = double.Parse(Console.ReadLine());
                    Console.Write("Ingrese la altura del rectángulo: ");
                    CalculadoraGeometria.AltoRectangulo = double.Parse(Console.ReadLine());
                    Console.WriteLine($"Área del rectángulo: {CalculadoraGeometria.CalcularAreaRectangulo()}");
                    Console.WriteLine($"Perímetro del rectángulo: {CalculadoraGeometria.CalcularPerimetroRectangulo()}");
                    break;
                case 3:
                    Console.WriteLine("Saliendo del programa...");
                    break;
                default:
                    Console.WriteLine("Opción no válida. Intente nuevamente.");
                    break;
            }
        } while (opcion != 3);

        static int Menu()
        {
            int opcion;
            Console.WriteLine("Seleccione una opción:");
            Console.WriteLine("1. Calcular área y perímetro de un círculo");
            Console.WriteLine("2. Calcular área y perímetro de un rectángulo");
            Console.WriteLine("3. Salir");

            opcion = int.Parse(Console.ReadLine());
            return opcion;
        }
    }
}
