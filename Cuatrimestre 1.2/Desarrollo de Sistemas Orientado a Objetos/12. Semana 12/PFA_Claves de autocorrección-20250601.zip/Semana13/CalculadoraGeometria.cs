﻿using System;


namespace Semana13
{
    public class CalculadoraGeometria
    {
        public static double RadioCirculo { get; set; }
        public static double AnchoRectangulo { get; set; }
        public static double AltoRectangulo { get; set; }

        public static double CalcularAreaCirculo()
        {
            return Math.PI * Math.Pow(RadioCirculo, 2);
        }

        public static double CalcularPerimetroCirculo()
        {
            return 2 * Math.PI * RadioCirculo;
        }

        public static double CalcularAreaRectangulo()
        {
            return AnchoRectangulo * AltoRectangulo;
        }

        public static double CalcularPerimetroRectangulo()
        {
            return 2 * (AnchoRectangulo + AltoRectangulo);
        }
    }
}
